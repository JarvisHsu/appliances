create
    definer = root@`%` procedure proc_userAddr()
BEGIN
    DECLARE i int default 1;
    while i < 4
        do
            insert into userAddr
            values (default, 1001, concat(i, '省'), concat(i, '市'), concat(i, '区'), concat(i, '路', i + 1, '号'),
                    round((13312312312 + RAND() * 1000000), 0));
            set i = i + 1;
        end while;

    set i = 1;
    while i < 5
        do
            insert into userAddr
            values (default, 1002, concat(i + 1, '省'), concat(i + 2, '市'), concat(i - 1, '区'),
                    concat(i - 1, '路', i, '号'), round(13321321212 + RAND() * 1000000, 0));
            set i = i + 1;
        end while;
    set i = 1;
    while i < 2
        do
            insert into userAddr
            values (default, 1004, concat(i + 5, '省'), concat(i + 2, '市'), concat(i - 1, '区'),
                    concat(i - 1, '路', i, '号'), round(13325671212 + RAND() * 1000000, 0));
            set i = i + 1;
        end while;
    set i = 1;
    while i < 3
        do
            insert into userAddr
            values (default, 1005, concat(i + 3, '省'), concat(i + 2, '市'), concat(i - 1, '区'),
                    concat(i - 1, '路', i, '号'), round(13327891212 + RAND() * 1000000, 0));
            set i = i + 1;
        end while;
end;

