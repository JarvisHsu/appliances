create
    definer = root@`%` procedure proc_userLogin()
BEGIN
    DECLARE i int default 1;
    while i < 10
        do
            INSERT into userlogin VALUES (DEFAULT, MD5('192837'));
            set i = i + 1;
        end while;
end;

